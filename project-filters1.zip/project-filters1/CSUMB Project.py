import os
import cv2
import numpy as np

# List images inside a folder
def list_images(folder="hw3_images"):
    # Resolve the absolute path of the folder relative to the project-filters directory
    folder = os.path.abspath(os.path.join(os.path.dirname(__file__), folder))
    print(f"Resolved folder path: {folder}")  # Debugging information

    # Ensure the folder exists
    if not os.path.exists(folder):
        print(f"Error: The folder '{folder}' does not exist.")
        return []

    # Debugging: List all files in the folder
    print(f"Files in folder: {os.listdir(folder)}")

    # Filter supported image files
    supported = [".jpg", ".jpeg", ".png", ".bmp"]
    files = [f for f in os.listdir(folder) if os.path.splitext(f)[1].lower() in supported]

    # Added a check to ensure the folder contains supported image files
    if not files:
        print(f"No supported image files found in '{folder}'.")
        return []

    # Debugging: List supported image files
    print(f"Supported image files: {files}")

    return files

# Filters definitions
def apply_polarizing_filter(image):
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
    cl = clahe.apply(l)
    merged = cv2.merge((cl, a, b))
    polarized = cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)
    return polarized

def apply_color_filter(image, color):
    overlay = np.zeros_like(image)
    if color == 'red':
        overlay[:, :, 2] = 100
    elif color == 'green':
        overlay[:, :, 1] = 100
    elif color == 'blue':
        overlay[:, :, 0] = 100
    else:
        print(f"Unsupported color '{color}'. Defaulting to no filter.")
        return image
    filtered = cv2.addWeighted(image, 0.7, overlay, 0.3, 0)
    return filtered

def apply_night_filter(image):
    night = cv2.addWeighted(image, 0.5, np.zeros_like(image), 0.5, 0)
    blue_overlay = np.full_like(image, (50, 0, 0))
    night = cv2.addWeighted(night, 0.8, blue_overlay, 0.2, 0)
    return night

def apply_macro_filter(image):
    h, w = image.shape[:2]
    mask = np.zeros((h, w), dtype=np.uint8)
    cv2.circle(mask, (w // 2, h // 2), min(w, h) // 4, 255, -1)
    blurred = cv2.GaussianBlur(image, (21, 21), 0)
    sharp = cv2.addWeighted(image, 2, blurred, -1, 0)
    macro = np.where(mask[:, :, None] == 255, sharp, blurred)
    return macro

def apply_greyscale_filter(image):
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

def apply_invert_colors_filter(image):
    return cv2.bitwise_not(image)

def apply_warm_filter(image):
    increase_lookup_table = np.array([min(i+30, 255) for i in range(256)]).astype("uint8")
    b, g, r = cv2.split(image)
    r = cv2.LUT(r, increase_lookup_table)
    warm_image = cv2.merge((b, g, r))
    return warm_image

def apply_cool_filter(image):
    decrease_lookup_table = np.array([max(i-30, 0) for i in range(256)]).astype("uint8")
    b, g, r = cv2.split(image)
    b = cv2.LUT(b, decrease_lookup_table)
    cool_image = cv2.merge((b, g, r))
    return cool_image

# Main program
def main():
    # Set the folder to "hw3_images" relative to the current script's directory
    folder = os.path.abspath(os.path.join(os.path.dirname(__file__), "hw3_images"))
    images = list_images(folder)

    if not images:
        print(f"No images found inside '{folder}'.")
        print("➡ Please make sure you have .jpg, .jpeg, .png, or .bmp images inside the folder!")
        return

    print("Available images:")
    for idx, img in enumerate(images):
        print(f"{idx+1}: {img}")

    choice = input(f"Enter the number of the image to use (1-{len(images)}): ").strip()
    if not choice.isdigit() or int(choice) < 1 or int(choice) > len(images):
        print("Invalid choice.")
        return

    filename = images[int(choice) - 1]
    path = os.path.join(folder, filename)

    # Check if the file exists before attempting to read
    if not os.path.exists(path):
        print(f"Error: The file '{path}' does not exist.")
        return

    # Attempt to read the image
    image = cv2.imread(path)
    if image is None:
        print(f"Error: Failed to load image at '{path}'. Please ensure the file is a valid image.")
        return

    print("Choose a filter:")
    print("1: Polarizing filter")
    print("2: Color filter (red/green/blue)")
    print("3: Night filter")
    print("4: Macro filter")
    print("5: Greyscale filter")
    print("6: Invert colors filter")
    print("7: Warm filter")
    print("8: Cool filter")

    filter_choice = input("Enter your choice (1-8): ").strip()

    if filter_choice == '1':
        result = apply_polarizing_filter(image)
    elif filter_choice == '2':
        color = input("Enter color (red/green/blue): ").lower().strip()
        result = apply_color_filter(image, color)
    elif filter_choice == '3':
        result = apply_night_filter(image)
    elif filter_choice == '4':
        result = apply_macro_filter(image)
    elif filter_choice == '5':
        result = apply_greyscale_filter(image)
    elif filter_choice == '6':
        result = apply_invert_colors_filter(image)
    elif filter_choice == '7':
        result = apply_warm_filter(image)
    elif filter_choice == '8':
        result = apply_cool_filter(image)
    else:
        print("Invalid choice.")
        return

    if len(result.shape) == 2:  # Greyscale image handling
        cv2.imshow('Filtered Image', result)
    else:
        cv2.imshow('Filtered Image', result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
